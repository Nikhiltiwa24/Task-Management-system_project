from django.shortcuts import render, redirect
from .models import Task  # import your Task model
from .forms import TaskForm  # import the form
from django.shortcuts import get_object_or_404

def task_list(request):
    form = TaskForm(request.POST or None)

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('task-list')  # refresh the page after adding
    tasks = Task.objects.all()  # get all tasks from database
    return render(request, 'todo/task_list.html', {'tasks': tasks, 'form': form})

def complete_task(request, pk):
    task = get_object_or_404(Task, pk=pk)
    task.completed = not task.completed  # toggle completed status
    task.save()
    return redirect('task-list')

def delete_task(request, pk):
    task = get_object_or_404(Task, pk=pk)
    task.delete()
    return redirect('task-list')

def toggle_task (request, pk):
    task = get_object_or_404(Task, pk=pk)
    task.completed = not task.completed
    task.save()
    return redirect('task-list')