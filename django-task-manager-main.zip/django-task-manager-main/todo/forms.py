from django import forms
from .models import Task

class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ['title']  # only ask for title in the form
        widgets = {
            'title': forms.TextInput(attrs={'placeholder': 'Enter a new task'})
        }

    def clean_title(self):
        title = self.cleaned_data.get('title')
        if not title:
            raise forms.ValidationError("Title cannot be empty")
        return title
