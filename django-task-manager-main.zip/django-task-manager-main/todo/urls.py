from django.urls import path
from . import views

urlpatterns = [
    path('', views.task_list, name='task-list'),
    path('complete/<int:pk>/', views.complete_task, name='complete-task'),
    path('delete/<int:pk>/', views.delete_task, name='delete-task'),
    path('toggle/<int:pk>/', views.toggle_task, name='toggle-task'),

]
